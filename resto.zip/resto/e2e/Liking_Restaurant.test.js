/* eslint-disable indent */
/* eslint-disable no-unused-vars */
/* eslint-disable no-undef */
const assert = require('assert');

Feature('Liking Restaurant');

Scenario('showing empty liked restaurant', ({ I }) => {
    I.amOnPage('/#/favorite');
    I.seeElement('#content');
    I.seeElement('#restaurant');
    I.see('Tidak ada kafe untuk ditampilkan', '.restaurant-item__not__found');
});
